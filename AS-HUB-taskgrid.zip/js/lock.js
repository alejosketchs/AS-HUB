// AS HUB — bloqueo por PIN (se comparte entre dispositivos vía Supabase)
import { sb } from './db.js';
import { $, $$, toast } from './ui.js';

const UNLOCK_KEY = 'ashub:unlocked';
const UNLOCK_DAYS = 30;
const ROW_ID = 'auth';

async function sha256(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function readStoredHash() {
  const { data, error } = await sb.from('suite_data').select('payload').eq('id', ROW_ID).maybeSingle();
  if (error) throw error;
  return data?.payload?.pin_hash ?? null;
}

async function saveHash(hash) {
  const { error } = await sb.from('suite_data')
    .upsert({ id: ROW_ID, payload: { pin_hash: hash }, updated_at: new Date().toISOString() });
  if (error) throw error;
}

function deviceUnlocked() {
  try {
    const until = Number(localStorage.getItem(UNLOCK_KEY) || 0);
    return until > Date.now();
  } catch { return false; }
}

function rememberDevice() {
  try {
    localStorage.setItem(UNLOCK_KEY, String(Date.now() + UNLOCK_DAYS * 864e5));
  } catch { /* modo privado */ }
}

export function forgetDevice() {
  try { localStorage.removeItem(UNLOCK_KEY); } catch { /* noop */ }
}

/**
 * Muestra el teclado y resuelve cuando el PIN es correcto.
 * Si no hay PIN guardado, el primero que se escriba queda registrado.
 */
export function requirePin() {
  return new Promise((resolve) => {
    const lock = $('#lock');
    const dots = $('#lockDots');
    const pad = $('#keypad');
    let buffer = '';
    let storedHash = null;
    let creating = false;
    let firstEntry = null;
    const subtitle = lock.querySelector('p');

    lock.classList.remove('hide');

    const paint = () => {
      $$('i', dots).forEach((d, i) => d.classList.toggle('on', i < buffer.length));
    };

    const fail = (msg) => {
      buffer = ''; paint();
      lock.classList.add('is-wrong');
      setTimeout(() => lock.classList.remove('is-wrong'), 420);
      toast(msg, 'err');
    };

    const done = () => {
      rememberDevice();
      lock.classList.add('hide');
      document.removeEventListener('keydown', onKey);
      resolve();
    };

    const submit = async () => {
      const pin = buffer;
      buffer = ''; paint();

      if (creating) {
        if (!firstEntry) {
          firstEntry = pin;
          subtitle.textContent = 'Repite el PIN para confirmarlo';
          return;
        }
        if (firstEntry !== pin) {
          firstEntry = null;
          subtitle.textContent = 'Crea un PIN de 4 dígitos';
          return fail('No coincide, intenta de nuevo');
        }
        try {
          await saveHash(await sha256(pin));
          toast('PIN creado');
          done();
        } catch {
          fail('No se pudo guardar el PIN');
        }
        return;
      }

      if ((await sha256(pin)) === storedHash) done();
      else fail('PIN incorrecto');
    };

    const press = (key) => {
      if (key === 'del') { buffer = buffer.slice(0, -1); return paint(); }
      if (key === 'reset') {
        forgetDevice();
        buffer = ''; paint();
        return toast('Este dispositivo pedirá el PIN de nuevo', 'info');
      }
      if (!/^\d$/.test(key) || buffer.length >= 4) return;
      buffer += key;
      paint();
      if (buffer.length === 4) setTimeout(submit, 90);
    };

    const onKey = (e) => {
      if (/^\d$/.test(e.key)) press(e.key);
      else if (e.key === 'Backspace') press('del');
    };

    pad.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-k]');
      if (b) press(b.dataset.k);
    });
    document.addEventListener('keydown', onKey);

    (async () => {
      try {
        storedHash = await readStoredHash();
      } catch {
        // Sin conexión: si el dispositivo ya estaba autorizado, se deja pasar.
        if (deviceUnlocked()) return done();
        subtitle.textContent = 'Sin conexión. Conéctate una vez para entrar.';
        return;
      }
      if (!storedHash) {
        creating = true;
        subtitle.textContent = 'Crea un PIN de 4 dígitos';
      } else if (deviceUnlocked()) {
        done();
      }
    })();
  });
}
