// AS HUB — configuración
export const SUPABASE_URL = 'https://derzetuipyugmrjaxcyu.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_XC5v-_UBfrsnbTLIJPqe6w_xXz3tCA6';

export const TZ = 'America/Bogota';
export const CURRENCY = 'COP';

export const APP_VERSION = '2.0.0';

export const FRASES = [
  'La prisa hace ruido; el rumbo hace progreso.',
  'Hecho es mejor que perfecto, pero no mejor que pensado.',
  'Lo que no se mide, se inventa.',
  'Un día ordenado vale por tres improvisados.',
  'El dinero se va por donde nadie está mirando.',
  'Empieza pequeño, pero empieza hoy.',
  'La constancia le gana al talento cuando el talento no aparece.',
  'No hay atajos hacia donde vale la pena llegar.',
  'Tu yo de mañana agradece lo que hiciste hoy.',
  'Cierra ciclos: lo abierto pesa más que lo difícil.',
  'Gastar menos también es ganar más.',
  'La claridad es una decisión, no una casualidad.',
  'Menos ruido. Más vida.',
  'Lo urgente grita; lo importante susurra.',
];
