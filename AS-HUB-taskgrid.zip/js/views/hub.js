// AS HUB — pantalla de inicio
import { Tasks, Finance, cached } from '../db.js';
import { html, raw, money, moneyShort, todayISO, dayOf, monthRange, pct, $ } from '../ui.js';
import { FRASES } from '../config.js';

function fraseDelDia() {
  const iso = todayISO();
  const seed = Number(iso.replaceAll('-', '')) % FRASES.length;
  return FRASES[seed];
}

function saludo() {
  const h = Number(new Date().toLocaleString('en-US', { timeZone: 'America/Bogota', hour: '2-digit', hour12: false }));
  if (h < 6) return 'Trasnochando';
  if (h < 12) return 'Buenos días';
  if (h < 19) return 'Buenas tardes';
  return 'Buenas noches';
}

const shell = (tasksStats, moneyStats) => html`
  <section class="view">
    <div class="viewHead">
      <div>
        <span class="tag">${saludo().toUpperCase()}, ALEJO</span>
        <h1 class="display">ELIGE TU<em>PRÓXIMA MISIÓN.</em></h1>
      </div>
      <p>Tareas y finanzas en un solo lugar, sincronizadas entre tu celular y tu computador.</p>
    </div>

    <div class="appGrid">
      <a class="appCard tilt-a" href="#/tareas" style="--accent:var(--yellow)">
        <span class="appNum">#01</span>
        <div class="appIcon">✓</div>
        <p class="appLabel">ORGANIZA EL CAOS</p>
        <h2>Tareas</h2>
        <p>Inbox, agenda del día, proyectos y post-its. Todo lo que tienes pendiente, sin ruido.</p>
        <div class="appStats">${raw(tasksStats)}</div>
        <div class="appOpen">ABRIR <b>↗</b></div>
      </a>

      <a class="appCard tilt-b" href="#/finanzas" style="--accent:var(--lime)">
        <span class="appNum">#02</span>
        <div class="appIcon">$</div>
        <p class="appLabel">DINERO SIN DRAMA</p>
        <h2>Finanzas</h2>
        <p>Movimientos, presupuesto, metas y deudas. Perfiles separados para Chori y Toli.</p>
        <div class="appStats">${raw(moneyStats)}</div>
        <div class="appOpen">ABRIR <b>↗</b></div>
      </a>
    </div>

    <aside class="daily">
      <span>✦ MENSAJE DEL DÍA</span>
      <p>${fraseDelDia()}</p>
      <b>— AS ORACLE</b>
    </aside>

    <div class="statGrid" id="hubStats" style="margin-top:34px"></div>
  </section>`;

const chip = (t) => `<span>${t}</span>`;

export async function render(root) {
  root.innerHTML = shell(chip('Cargando…'), chip('Cargando…'));

  const today = todayISO();
  const now = new Date(today + 'T12:00:00');
  const { from, to } = monthRange(now.getFullYear(), now.getMonth() + 1);

  const paint = ({ tasks, txs, budgets }) => {
    const open = tasks.filter((t) => t.status !== 'done');
    const dueToday = open.filter((t) => t.due_date === today).length;
    const late = open.filter((t) => t.due_date && t.due_date < today).length;
    const doneToday = tasks.filter((t) => t.status === 'done' && dayOf(t.completed_at) === today).length;

    const spent = txs.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0);
    const income = txs.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0);
    const planned = budgets.filter((b) => b.active).reduce((s, b) => s + Number(b.amount), 0);

    const tChips = [chip(`${open.length} abiertas`), chip(`${dueToday} para hoy`)];
    if (late) tChips.push(chip(`⚠ ${late} vencidas`));
    const mChips = [chip(`${moneyShort(spent)} gastado`), chip(`${planned ? pct(spent, planned) : 0}% del plan`)];

    const cards = root.querySelectorAll('.appStats');
    if (cards[0]) cards[0].innerHTML = tChips.join('');
    if (cards[1]) cards[1].innerHTML = mChips.join('');

    const free = Math.max(0, planned - spent);
    $('#hubStats', root).innerHTML = html`
      <article class="stat yellow">
        <span>MISIÓN · TAREAS</span>
        <strong>${String(doneToday)}</strong>
        <div class="bar"><i style="width:${String(pct(doneToday, doneToday + open.length))}%"></i></div>
        <small>completadas hoy · ${String(open.length)} pendientes</small>
      </article>
      <article class="stat lime">
        <span>STATUS · GASTO DEL MES</span>
        <strong>${money(spent)}</strong>
        <div class="bar ${planned && spent > planned ? 'over' : ''}"><i style="width:${String(pct(spent, planned))}%"></i></div>
        <small>${planned ? money(free) + ' libres del presupuesto' : 'sin presupuesto configurado'}</small>
      </article>
      <article class="stat blue">
        <span>INGRESOS DEL MES</span>
        <strong>${money(income)}</strong>
        <div class="bar"><i style="width:${String(pct(income, Math.max(income, spent)))}%"></i></div>
        <small>balance ${money(income - spent)}</small>
      </article>`;
  };

  try {
    await cached('hub', async () => {
      const [tasks, txs, budgets] = await Promise.all([
        Tasks.list(),
        Finance.transactions('alejo', from, to),
        Finance.budgets('alejo'),
      ]);
      return { tasks, txs, budgets };
    }, paint);
  } catch {
    const cards = root.querySelectorAll('.appStats');
    if (cards[0]) cards[0].innerHTML = chip('sin conexión');
    if (cards[1]) cards[1].innerHTML = chip('sin conexión');
  }
}
