// AS HUB — Finanzas (recreación de AS Finanzas en curso)
import { html } from '../ui.js';

export async function render(root) {
  root.innerHTML = html`
    <section class="view">
      <div class="viewHead">
        <div>
          <span class="tag tag--lime">MISIÓN 02</span>
          <h1 class="display">FINANZAS<em>en obra.</em></h1>
        </div>
      </div>
      <div class="empty" style="padding:52px 24px">
        <b>🚧</b>
        <p>Estoy recreando AS Finanzas tal como está en tus pantallazos:
        movimientos, presupuesto dividido, ritmo semanal, metas, categorías,
        deudas y estadísticas.</p>
        <p style="margin-top:10px"><b style="font-size:13px">Tus datos están intactos en la base.</b>
        Nada se perdió; solo falta la pantalla.</p>
      </div>
    </section>`;
}
